package com.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.dto.RegRespDto;
import com.dto.RegisterDto;
import com.entity.Customer;
import com.entity.Login;
import com.exception.CustomerNotFoundException;

public interface CustomerRepo extends JpaRepository<Customer, Long>{
	Customer findByLogin(Login login) ;
	List<Customer> findByfullName(String name);
	

	@Query(value = "SELECT c.* FROM customer c JOIN login l ON c.email = l.email WHERE l.email = :email", nativeQuery = true)
	Customer findByEmail(String email);

}
