package com.servive;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.dto.AccountDto;
import com.entity.Account;
import com.entity.Customer;
import com.exception.AccountNotFoundException;
import com.repository.AccountRepo;
import com.repository.CustomerRepo;
import com.service.AccountServiceImpl;

@ExtendWith(MockitoExtension.class)
class AccountServiceImplTest {

    @Mock
    private AccountRepo accountRepo;

    @Mock
    private CustomerRepo customerRepo;

    @InjectMocks
    private AccountServiceImpl accountService;

    private Account account;
    private AccountDto accountDto;
    private Customer customer;

    @BeforeEach
    void setUp() {
        customer = new Customer();
        customer.setCustId(1L);
        customer.setFullName("John Doe");

        account = new Account();
        account.setAccId(1001L);
        account.setAccType("Savings");
        account.setBalance(5000.0);
        account.setCreatedAt(LocalDate.now().toString());
        account.setCustomer(customer);

        accountDto = new AccountDto(
            account.getAccId(),
            account.getAccType(),
            customer.getCustId(),
            account.getBalance(),
            account.getCreatedAt(),
            account.getisFreeze()
        );
    }

    @Test
    void testAddAccount_Success() {
        when(customerRepo.getById(anyLong())).thenReturn(customer);
        when(accountRepo.save(account)).thenReturn(account);

        Account savedAccount = accountService.addAccount(account);

        assertNotNull(savedAccount);
        assertEquals("Savings", savedAccount.getAccType());
        assertEquals(5000.0, savedAccount.getBalance());
        verify(accountRepo, times(1)).save(account);
    }

    @Test
    void testGetAccountById_Success() throws AccountNotFoundException {
        when(accountRepo.findById(1001L)).thenReturn(Optional.of(account));

        AccountDto retrievedAccountDto = accountService.getAccountDetailsById(1001L);

        assertNotNull(retrievedAccountDto);
        assertEquals("Savings", retrievedAccountDto.getAccType());
        assertEquals(5000.0, retrievedAccountDto.getBalance());
    }

    @Test
    void testGetAccountById_ThrowsException() {
        when(accountRepo.findById(9999L)).thenReturn(Optional.empty());

        assertThrows(AccountNotFoundException.class, () -> {
            accountService.getAccountDetailsById(9999L);
        });
    }

    @Test
    void testGetAllAccounts() {
        when(accountRepo.findAll()).thenReturn(Arrays.asList(account));

        assertFalse(accountService.getAllAccounts().isEmpty());
        verify(accountRepo, times(1)).findAll();
    }

    @Test
    void testDeleteAccount_Success() throws AccountNotFoundException {
        when(accountRepo.findById(1001L)).thenReturn(Optional.of(account));

        accountService.deleteAccount(1001L);

        verify(accountRepo, times(1)).deleteById(1001L);
    }

    @Test
    void testDeleteAccount_ThrowsException() {
        when(accountRepo.findById(9999L)).thenReturn(Optional.empty());

        assertThrows(AccountNotFoundException.class, () -> {
            accountService.deleteAccount(9999L);
        });
    }

    @Test
    void testFreezeAccount() throws AccountNotFoundException {
        when(accountRepo.findById(1001L)).thenReturn(Optional.of(account));
        when(accountRepo.freezeAccount(1001L)).thenReturn(1);

        assertEquals(1, accountService.freezeAccount(1001L));
    }
    
    @Test
    void testUnfreezeAccount() throws AccountNotFoundException {
        when(accountRepo.findById(1001L)).thenReturn(Optional.of(account));
        when(accountRepo.unFreezeAccount(1001L)).thenReturn(1);

        assertEquals(1, accountService.unFreezeAccount(1001L));
    }

}
