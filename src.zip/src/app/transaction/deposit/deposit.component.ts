import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { AuthService } from 'src/app/all.service';

@Component({
  selector: 'app-deposit',
  templateUrl: './deposit.component.html',
  styleUrls: ['./deposit.component.css']
})
export class DepositComponent implements OnInit {
  depositForm!: FormGroup;
  message: string = '';
  messageType: string = '';
  customerId: number = 0;
  userAccounts: any[] = [];

  constructor(private service: AuthService) { }

  ngOnInit() {
    this.depositForm = new FormGroup({
      accId: new FormControl(0, [Validators.required]),
      amount: new FormControl('', [Validators.required, Validators.min(500)])
    });
    const email = sessionStorage.getItem('userEmail');
    if (email) {
      this.service.getCustomerDetails(email).subscribe(data => {
        this.customerId = Number(data.custId);
        this.service.getAccountsByCustomerId(this.customerId).subscribe(accounts => {
          this.userAccounts = accounts.map(acc => acc.accountId);
        });
      });
    }
  }

  deposit() {
    if (this.depositForm.valid) {
      const depositData = this.depositForm.getRawValue();
      console.log(depositData)
      if (!this.userAccounts.includes(Number(depositData.accId))) {
        this.message = 'Transaction failed: You can only deposit into your own account.';
        this.messageType = 'error';
        return;
      }
      this.service.deposit(depositData.amount, depositData.accId).subscribe(
        response => {
          this.message = response.message;
          this.messageType = response.status === 'success' ? 'success' : 'error';
        },
        error => {
          this.message = 'Deposit failed. Please try again.';
          this.messageType = 'error';
        }
      );
    } else {
      this.message = 'Please enter a valid amount and account ID.';
      this.messageType = 'error';
    }
  }
}


