import { Component, OnInit } from '@angular/core';
import { AuthService, Transaction } from 'src/app/all.service';

@Component({
  selector: 'app-get-all-transac',
  templateUrl: './get-all-transac.component.html',
  styleUrls: ['./get-all-transac.component.css']
})
export class GetAllTransacComponent implements OnInit {
  transactions: Transaction[] = [];
  message: string = '';
  messageType: String = '';

  constructor(private service: AuthService) { }
  ngOnInit(): void {
    this.getAllTransactions();
  }

  getAllTransactions() {
    this.service.getAllTransactions().subscribe(
      response => {
        this.transactions = response;
        this.message = response.length > 0 ? 'Transactions retrieved successfully.' : 'No transactions found.';
        this.messageType = response.length > 0 ? 'success' : 'error';
      },
      error => {
        this.message = 'Failed to retrieve transactions. Please try again.';
        this.messageType = 'error';
      }
    );
  }
}
