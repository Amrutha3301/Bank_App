package com.service;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.entity.Login;
import com.repository.LoginRepo;

@Service
public class LoginServiceImpl implements LoginService {
	
	@Autowired
	LoginRepo loginRepo;

	@Override
	public Map<String, String> loginUser(Login login) {
		Map<String, String> response = new HashMap<>();
		Login log = loginRepo.findByEmailAndPassword(login.getEmail(), login.getPassword());
		if(log!=null) {
			response.put("message", "Successfully Logged In!!!");
		}else
		response.put("message", "Invalid email or password") ;
		return response;
	}

	@Override
	public String getUserRole(String email) {
		Optional<Login> login= loginRepo.findById(email);
		if(login.isPresent()) {
			return login.get().getRole();
		}
		else return "User not found";
	}

}
