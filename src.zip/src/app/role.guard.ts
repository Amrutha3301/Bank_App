import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { map, Observable } from 'rxjs';
import { AuthService } from './all.service';

@Injectable({
  providedIn: 'root'
})
export class RoleGuard implements CanActivate {
  constructor(private authService: AuthService, private router: Router) { }

  canActivate(): Observable<boolean> {
    const email = sessionStorage.getItem('userEmail');

    if (!email) {
      this.router.navigate(['/login']);
      return new Observable(observer => observer.next(false));
    }

    return this.authService.getRole(email).pipe(
      map(role => {
        if (role.toLowerCase() === 'admin') {
          return true;
        }
        this.router.navigate(['/unauthorized']);
        return false;
      })
    );
  }

}
