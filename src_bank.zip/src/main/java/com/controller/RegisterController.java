package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.dto.RegRespDto;
import com.dto.RegisterDto;
import com.service.RegisterService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class RegisterController {
	
	@Autowired
	RegisterService regService;
	
	@PostMapping("auth/register")
	public RegRespDto registerUser(@RequestBody RegisterDto customer){
		RegRespDto response = regService.registerCust(customer);
		return response;
	}
}
