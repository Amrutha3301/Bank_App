package com.advice;

import java.util.HashMap;
import java.util.Map;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.exception.AccountNotFoundException;
import com.exception.CustomerFoundException;
import com.exception.CustomerNotFoundException;

@RestControllerAdvice
public class GlobalExceptionHandler {

	@ExceptionHandler(CustomerNotFoundException.class)
    public ResponseEntity<?> handleCustomerNotFoundException(CustomerNotFoundException ex) {
        
        return new ResponseEntity<>(ex.getMessage().toString(), HttpStatus.NOT_FOUND);
    }

	@ExceptionHandler(AccountNotFoundException.class)
    public ResponseEntity<?> handleAccountNotFoundException(AccountNotFoundException ex) {
        
        return new ResponseEntity<>(ex.getMessage().toString(), HttpStatus.NOT_FOUND);
    }
	
	@ExceptionHandler(CustomerFoundException.class)
    public ResponseEntity<?> handleCustomerFoundException(CustomerFoundException ex) {
        
        return new ResponseEntity<>(ex.getMessage().toString(), HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<String> handleValidationExceptions(MethodArgumentNotValidException ex) {
        StringBuilder errors = new StringBuilder("Validation Failed!!! ");
        ex.getBindingResult().getFieldErrors().forEach(error -> 
            errors.append(error.getDefaultMessage())
        );
        return new ResponseEntity<>(errors.toString(), HttpStatus.BAD_REQUEST);
    }
}
