import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  userRole: string = '';
  usdRate: number | null = null;
  eurRate: number | null = null;
  loanAmount: number | null = null;
  interestRate: number | null = null;
  tenure: number | null = null;
  emiResult: number | null = null;
  securityAlerts: string[] = [];
  nifty50: number = 0;
  niftyChange: number = 0;
  mutualFundGrowth: string = '';
  investmentRecommendations: string[] = [];

  constructor() { }

  ngOnInit() {
    this.userRole = sessionStorage.getItem('userRole') || '';
    this.loadSecurityAlerts();
    this.fetchExchangeRates();
    this.fetchNiftyData();
  }

  fetchExchangeRates() {
    setTimeout(() => {
      this.usdRate = 82.50;
      this.eurRate = 90.20;
    }, 1000);
  }
  calculateEMI() {
    if (this.loanAmount && this.interestRate && this.tenure) {
      const monthlyRate = this.interestRate / (12 * 100);
      const months = this.tenure * 12;
      this.emiResult = (this.loanAmount * monthlyRate * Math.pow(1 + monthlyRate, months)) /
        (Math.pow(1 + monthlyRate, months) - 1);
    } else {
      this.emiResult = null;
    }
  }

  loadSecurityAlerts() {
    this.securityAlerts = [
      "⚠️ Beware of phishing emails asking for OTPs.",
      "✅ Enable two-factor authentication for extra security.",
      "🔒 Never share your banking credentials with anyone.",
      "🚨 Report suspicious transactions immediately."
    ];
  }

  fetchNiftyData() {
    this.investmentRecommendations = [
      "📈 Invest in blue-chip stocks for stable long-term growth.",
      "💰 Consider mutual funds with a strong 5-year performance.",
      "🔍 Diversify your portfolio to minimize risk.",
      "🏡 Real estate investments can provide passive income."
    ];
  }
}
