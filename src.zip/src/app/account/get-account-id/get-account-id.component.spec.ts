import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GetAccountIdComponent } from './get-account-id.component';

describe('GetAccountIdComponent', () => {
  let component: GetAccountIdComponent;
  let fixture: ComponentFixture<GetAccountIdComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GetAccountIdComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(GetAccountIdComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
