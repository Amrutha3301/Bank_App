import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../all.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm!: FormGroup;
  errorMessage: string = '';
  loginAttempts: number = 0;
  lockoutTimer: number = 0;
  interval: any;
  isLocked: boolean = false;

  constructor(private fb: FormBuilder, private service: AuthService, private router: Router) { }

  ngOnInit(): void {
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required]
    });

    this.loadLockoutState();
  }

  login() {
    if (this.isLocked) return;

    if (this.loginForm.valid) {
      const { email, password } = this.loginForm.value;
      this.service.userLogin(email, password).subscribe(
        (response) => {
          if (response['message'] === 'Successfully Logged In!!!') {
            this.service.getRole(email).subscribe(
              (role) => {
                this.resetLoginAttempts(); // Successful login resets attempts
                if (role.toLowerCase() === 'admin' || role.toLowerCase() === 'user') {
                  this.router.navigate(['home']);
                }
              },
              () => {
                this.errorMessage = 'Failed to fetch user role. Please try again later.';
              }
            );
          } else {
            this.handleFailedLogin();
          }
        },
        () => {
          this.handleFailedLogin();
        }
      );
    }
  }

  handleFailedLogin() {
    this.loginAttempts++;
    localStorage.setItem('loginAttempts', this.loginAttempts.toString());

    if (this.loginAttempts >= 3) {
      this.startLockout();
    } else {
      this.errorMessage = `Invalid email or password. Attempts left: ${3 - this.loginAttempts}`;
    }
  }

  startLockout() {
    this.isLocked = true;
    this.lockoutTimer = 60; // 1 minute
    localStorage.setItem('lockoutTime', Date.now().toString());
    localStorage.setItem('isLocked', 'true');
    this.errorMessage = 'Too many failed attempts. Please try again after 1 minute.';

    this.interval = setInterval(() => {
      this.lockoutTimer--;
      if (this.lockoutTimer <= 0) {
        this.resetLockout();
      }
    }, 1000);
  }

  resetLockout() {
    clearInterval(this.interval);
    this.isLocked = false;
    this.lockoutTimer = 0;
    this.loginAttempts = 0;
    localStorage.removeItem('loginAttempts');
    localStorage.removeItem('lockoutTime');
    localStorage.removeItem('isLocked');
  }

  resetLoginAttempts() {
    this.loginAttempts = 0;
    localStorage.removeItem('loginAttempts');
  }

  loadLockoutState() {
    const storedAttempts = localStorage.getItem('loginAttempts');
    const storedLockoutTime = localStorage.getItem('lockoutTime');
    const storedIsLocked = localStorage.getItem('isLocked');

    if (storedAttempts) {
      this.loginAttempts = parseInt(storedAttempts, 10);
    }

    if (storedIsLocked === 'true' && storedLockoutTime) {
      const elapsedTime = Math.floor((Date.now() - parseInt(storedLockoutTime, 10)) / 1000);
      if (elapsedTime < 60) {
        this.lockoutTimer = 60 - elapsedTime;
        this.isLocked = true;
        this.errorMessage = 'Too many failed attempts. Please try again after 1 minute.';
        this.interval = setInterval(() => {
          this.lockoutTimer--;
          if (this.lockoutTimer <= 0) {
            this.resetLockout();
          }
        }, 1000);
      } else {
        this.resetLockout();
      }
    }
  }
}
