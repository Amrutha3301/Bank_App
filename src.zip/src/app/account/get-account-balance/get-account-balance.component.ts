import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService, Balance } from 'src/app/all.service';

@Component({
  selector: 'app-get-account-balance',
  templateUrl: './get-account-balance.component.html',
  styleUrls: ['./get-account-balance.component.css']
})
export class GetAccountBalanceComponent implements OnInit {
  balanceForm!: FormGroup;
  balance: Balance | null = null;
  message: string = '';
  errorMessage: string = '';

  constructor(private fb: FormBuilder, private authService: AuthService) { }

  ngOnInit(): void {
    this.balanceForm = this.fb.group({
      accId: ['', [Validators.required, Validators.pattern('^[0-9]+$')]]
    });
  }

  getBalance(): void {
    if (this.balanceForm.invalid) {
      this.message = "Please enter a valid Account ID.";
      this.errorMessage = '';
      return;
    }

    const accId = Number(this.balanceForm.value.accId);

    this.authService.getAccountBalance(accId).subscribe({
      next: (data) => {
        this.balance = data;
        this.message = `Balance Retrieved Successfully`;
        this.errorMessage = '';
      },
      error: (error) => {
        if (error.status === 404) {
          this.balance = null;
          this.message = ``;
          this.errorMessage = `No Account Exists with ID ${accId}`;

        } else {
          this.message = '';
          this.errorMessage = 'Failed to retrieve balance. Please try again.';
        }
      }
    });
  }
}
