import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GetAccountByCustomerComponent } from './get-account-by-customer.component';

describe('GetAccountByCustomerComponent', () => {
  let component: GetAccountByCustomerComponent;
  let fixture: ComponentFixture<GetAccountByCustomerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GetAccountByCustomerComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(GetAccountByCustomerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
