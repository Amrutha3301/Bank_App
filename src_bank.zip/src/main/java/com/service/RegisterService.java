package com.service;

import com.dto.RegRespDto;
import com.dto.RegisterDto;

public interface RegisterService {
	RegRespDto registerCust(RegisterDto customer);
}
