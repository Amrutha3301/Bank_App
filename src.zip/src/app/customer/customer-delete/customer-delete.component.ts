import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/all.service';


@Component({
  selector: 'app-customer-delete',
  templateUrl: './customer-delete.component.html',
  styleUrls: ['./customer-delete.component.css']
})
export class CustomerDeleteComponent implements OnInit {
  customers: any[] = [];

  constructor(private authService: AuthService) { }

  ngOnInit(): void {
    this.loadCustomers();
  }

  loadCustomers(): void {
    this.authService.getAllCustomers().subscribe(data => {
      this.customers = data;
    });
  }

  deleteCustomer(custId: number): void {
    this.authService.deleteCustomer(custId).subscribe(() => {
      this.customers = this.customers.filter(customer => customer.custId !== custId);
    });
  }
}