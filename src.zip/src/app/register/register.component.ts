import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../all.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {
  registerForm: FormGroup;
  errorMessage: string | null = null;

  constructor(private fb: FormBuilder, private service: AuthService, private router: Router) {
    this.registerForm = this.fb.group({
      fullName: ['', Validators.required],
      contactNo: ['', [Validators.required, Validators.pattern('^[0-9]{10}$')]],
      address: this.fb.group({
        dNo: ['', Validators.required],
        streetName: ['', Validators.required],
        city: ['', Validators.required],
        state: ['', Validators.required],
        pincode: ['', [Validators.required, Validators.pattern('^[0-9]{6}$')]]
      }),
      login: this.fb.group({
        email: ['', [Validators.required, Validators.email]],
        password: ['', [Validators.required, Validators.minLength(8), Validators.maxLength(16), Validators.pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@#$%^&+=!])[A-Za-z\d@#$%^&+=!]{8,16}$/)]],
        confirmPassword: ['', Validators.required],
        role: ['', Validators.required]
      })
    });
  }

  onSubmit() {
    if (this.registerForm.valid) {
      const { password, confirmPassword } = this.registerForm.value.login;

      if (password !== confirmPassword) {
        this.errorMessage = 'Passwords do not match.';
        return;
      }

      this.service.register(this.registerForm.value).subscribe(
        (response) => {
          if (response.message.includes("You are Registered successfully")) {
            alert(response.message);
            this.router.navigate(['/login']);
          } else if (response.message.includes("Customer already Exists")) {
            alert(response.message);
            this.registerForm.reset();
          }
        },
        (error) => {
          console.error('Registration error', error);
          this.errorMessage = '❌ An error occurred. Please try again later.';
        }
      );
    } else {
      this.errorMessage = '⚠️ Please fill out the form correctly.';
    }
  }
}
