package com.exception;

public class AccountNotFoundException extends Exception {
	
	public AccountNotFoundException() {
		// TODO Auto-generated constructor stub
	}
	
	public AccountNotFoundException(String msg) {
		super(msg);
	}
}
