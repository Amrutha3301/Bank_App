package com.controller;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.dto.AccountDto;
import com.dto.DepositWithdrawDto;
import com.dto.TransactionDto;
import com.entity.Account;
import com.entity.Transaction;
import com.exception.AccountNotFoundException;
import com.service.AccountService;
import com.service.TransactionService;


import org.slf4j.Logger;


@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class TransactionController {
	
	@Autowired
	TransactionService transService;
	@Autowired
	AccountService accService;
	
	@PostMapping("/accounts/{accId}/deposit")
	public ResponseEntity<Map<String, String>> depositAmount(@PathVariable long accId, @RequestBody DepositWithdrawDto amount){
		Map<String, String>  message = transService.deposit(amount.getAmount(), accId);
		return new ResponseEntity<Map<String, String>>(message, HttpStatus.OK);
	}
	
	@PostMapping("/accounts/{accId}/withdraw")
	public ResponseEntity<Map<String, String>> withdrawAmount(@PathVariable long accId, @RequestBody DepositWithdrawDto amount){
		Map<String, String> message = transService.withdraw(amount.getAmount(), accId);
		return new ResponseEntity<Map<String, String>>(message, HttpStatus.OK);
	}
	
	@PostMapping("/accounts/{from}/transfer/{to}")
	public ResponseEntity<?> transferAmount(@PathVariable long from, @PathVariable long to, @RequestBody DepositWithdrawDto amount){
		Map<String, String> message= transService.transferAmount(from, to, amount.getAmount());
		return new ResponseEntity<Map<String, String>>(message, HttpStatus.OK);
	}
	
	@GetMapping("/accounts/{accId}/transactionsbyId")
	public ResponseEntity<?> getAllTransactions(@PathVariable long accId) throws AccountNotFoundException{
		List<TransactionDto> trans=transService.getTransactionsByAccountId(accId);
		if(trans.isEmpty()) {
			return new ResponseEntity<String>("Transactions does not Exist", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<TransactionDto>>(trans, HttpStatus.OK);
	}

	@GetMapping("/accounts/{accId}/transactions")
	public ResponseEntity<?> getTransactionsByAccountIdAndDateRange(@PathVariable Long accId,@RequestParam String startDate, @RequestParam String endDate) throws AccountNotFoundException{

		LocalDate start = LocalDate.parse(startDate, DateTimeFormatter.ISO_LOCAL_DATE);
		LocalDate end = LocalDate.parse(endDate, DateTimeFormatter.ISO_LOCAL_DATE);
		
		LocalDateTime startDateTime = start.atStartOfDay();
		LocalDateTime endDateTime = end.atTime(23, 59, 59);



		List<TransactionDto> tlist = transService.getTransactionsByAccountIdAndDateRange(accId, startDateTime, endDateTime);
		if(tlist.isEmpty()) {
			return new ResponseEntity<String>("No transactions exist", HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<List<TransactionDto>>(tlist, HttpStatus.OK);
		}
	
	@GetMapping("/accounts/transactions")
	public ResponseEntity<?> getTransactions(){
		List<TransactionDto> tlist = transService.getAllTransaction();
		if(tlist.isEmpty()) {
			return new ResponseEntity<String>("No transactions exist", HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<List<TransactionDto>>(tlist, HttpStatus.OK);
		
	}
}
