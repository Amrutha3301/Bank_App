import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GetAllTransacComponent } from './get-all-transac.component';

describe('GetAllTransacComponent', () => {
  let component: GetAllTransacComponent;
  let fixture: ComponentFixture<GetAllTransacComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GetAllTransacComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(GetAllTransacComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
