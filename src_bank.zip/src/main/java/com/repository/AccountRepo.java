package com.repository;
 
import  java.time.LocalDateTime;
import java.util.List;
 
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.entity.Account;
import com.entity.Customer;
import com.entity.Transaction;


public interface AccountRepo extends JpaRepository<Account, Long> {
List<Account> findByCustomerCustId(long CustId);
double getAccountBalanceByAccId(Long accId);
boolean existsById(Long accId);


@Modifying
@Query("UPDATE Account a SET a.isFreeze = true WHERE a.id = :accId")
int freezeAccount(long accId);

@Modifying
@Query("UPDATE Account a SET a.isFreeze = false WHERE a.id = :accId")
int unFreezeAccount(long accId);

@Query("SELECT a.customer FROM Account a WHERE a.id = :accId")
Customer getCustomerDetails(long accId);


@Query("SELECT t FROM Account a JOIN a.transac t WHERE a.accId = :accountId AND t.timeStamp BETWEEN :startDate AND :endDate")
List<Transaction> findTransactionsByAccIdAndDateRange(long accId, LocalDateTime startDate, LocalDateTime endDate);

}