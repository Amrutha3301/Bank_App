import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/all.service';

@Component({
  selector: 'app-get-account-by-customer',
  templateUrl: './get-account-by-customer.component.html',
  styleUrls: ['./get-account-by-customer.component.css']
})
export class GetAccountByCustomerComponent implements OnInit {
  customers: any[] = [];
  accounts: any[] = [];
  selectedCustomerId: number | null = null;

  constructor(private accountService: AuthService) { }

  ngOnInit(): void {
    this.getCustomers();
  }

  getCustomers(): void {
    this.accountService.getAllCustomers().subscribe({
      next: (data) => this.customers = data,
      error: (err) => console.error('Error fetching customers:', err)

    });
  }

  getAccountsByCustomer(): void {
    if (this.selectedCustomerId) {
      this.accountService.getAccountsByCustomerId(this.selectedCustomerId).subscribe({
        next: (data) => this.accounts = data,
        error: (err) => {
          console.error('Error fetching accounts:', err);
          this.accounts = [];
        }
      });
    }
  }
}
