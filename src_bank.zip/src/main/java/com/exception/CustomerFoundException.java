package com.exception;

public class CustomerFoundException extends Exception{
	public CustomerFoundException() {
		// TODO Auto-generated constructor stub
	}
	public CustomerFoundException(String msg) {
		super(msg);
	}
}
