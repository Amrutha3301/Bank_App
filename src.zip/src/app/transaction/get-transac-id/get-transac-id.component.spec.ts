import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GetTransacIdComponent } from './get-transac-id.component';

describe('GetTransacIdComponent', () => {
  let component: GetTransacIdComponent;
  let fixture: ComponentFixture<GetTransacIdComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GetTransacIdComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(GetTransacIdComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
