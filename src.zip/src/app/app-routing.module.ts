import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';
import { AdminDashboardComponent } from './admin/admin-dashboard/admin-dashboard.component';
import { UserDashboardComponent } from './user/user-dashboard/user-dashboard.component';
import { HomeComponent } from './home/home.component';
import { AddAccountComponent } from './account/add-account/add-account.component';
import { DeleteAccountComponent } from './account/delete-account/delete-account.component';
import { GetAccountComponent } from './account/get-account/get-account.component';
import { GetAccountBalanceComponent } from './account/get-account-balance/get-account-balance.component';
import { GetAccountIdComponent } from './account/get-account-id/get-account-id.component';
import { GetCustomerByAccountComponent } from './account/get-customer-by-account/get-customer-by-account.component';
import { GetAccountByCustomerComponent } from './account/get-account-by-customer/get-account-by-customer.component';
import { FreezeAccountComponent } from './account/freeze-account/freeze-account.component';
import { UnfreezeAccountComponent } from './account/unfreeze-account/unfreeze-account.component';
import { UpdateAccountComponent } from './account/update-account/update-account.component';
import { VerifyAccountComponent } from './account/verify-account/verify-account.component';
import { AuthGuard } from './auth.guard';
import { RoleGuard } from './role.guard';
import { UnauthorizedComponent } from './unauthorized/unauthorized.component';
import { CustomerAddComponent } from './customer/customer-add/customer-add.component';
import { CustomerListComponent } from './customer/customer-list/customer-list.component';
import { CustomerDeleteComponent } from './customer/customer-delete/customer-delete.component';
import { CustomerUpdateNameComponent } from './customer/customer-update-name/customer-update-name.component';
import { CustomerUpdateAddressComponent } from './customer/customer-update-address/customer-update-address.component';
import { CustomerDetailsComponent } from './customer/customer-details/customer-details.component';
import { CustomerUpdateDtoComponent } from './customer/customer-update-dto/customer-update-dto.component';
import { DepositComponent } from './transaction/deposit/deposit.component';
import { WithdrawComponent } from './transaction/withdraw/withdraw.component';
import { TransferComponent } from './transaction/transfer/transfer.component';
import { GetTransacIdComponent } from './transaction/get-transac-id/get-transac-id.component';
import { GetTransacIdDateComponent } from './transaction/get-transac-id-date/get-transac-id-date.component';
import { GetAllTransacComponent } from './transaction/get-all-transac/get-all-transac.component';

const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'home', component: HomeComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'login', component: LoginComponent },
  { path: 'unauthorized', component: UnauthorizedComponent },
  { path: 'admin-dashboard', component: AdminDashboardComponent, canActivate: [AuthGuard, RoleGuard] },
  { path: 'user-dashboard', component: UserDashboardComponent, canActivate: [AuthGuard] },
  { path: 'add-account', component: AddAccountComponent, canActivate: [AuthGuard] },
  { path: 'delete-account', component: DeleteAccountComponent, canActivate: [AuthGuard] },
  { path: 'update-account', component: UpdateAccountComponent, canActivate: [AuthGuard] },
  { path: 'get-account', component: GetAccountComponent, canActivate: [AuthGuard, RoleGuard] },
  { path: 'get-account-balance', component: GetAccountBalanceComponent, canActivate: [AuthGuard, RoleGuard] },
  { path: 'get-account-id', component: GetAccountIdComponent, canActivate: [AuthGuard] },
  { path: 'get-customer-by-account', component: GetCustomerByAccountComponent, canActivate: [AuthGuard] },
  { path: 'get-account-by-customer', component: GetAccountByCustomerComponent, canActivate: [AuthGuard] },
  { path: 'freeze-account', component: FreezeAccountComponent, canActivate: [AuthGuard, RoleGuard] },
  { path: 'unfreeze-account', component: UnfreezeAccountComponent, canActivate: [AuthGuard, RoleGuard] },
  { path: 'verify-account', component: VerifyAccountComponent, canActivate: [AuthGuard, RoleGuard] },
  { path: 'add-customer', component: CustomerAddComponent, canActivate: [AuthGuard, RoleGuard] },
  { path: 'customers', component: CustomerListComponent, canActivate: [AuthGuard, RoleGuard] },
  { path: 'delete-customer', component: CustomerDeleteComponent, canActivate: [AuthGuard, RoleGuard] },
  { path: 'update-name-customer', component: CustomerUpdateNameComponent, canActivate: [AuthGuard] },
  { path: 'update-address-customer', component: CustomerUpdateAddressComponent, canActivate: [AuthGuard] },
  { path: 'update-dto-customer', component: CustomerUpdateDtoComponent, canActivate: [AuthGuard] },
  { path: 'details-customer', component: CustomerDetailsComponent, canActivate: [AuthGuard, RoleGuard] },
  { path: 'deposit', component: DepositComponent, canActivate: [AuthGuard] },
  { path: 'withdraw', component: WithdrawComponent, canActivate: [AuthGuard] },
  { path: 'transfer', component: TransferComponent, canActivate: [AuthGuard] },
  { path: 'get-transac-id', component: GetTransacIdComponent, canActivate: [AuthGuard] },
  { path: 'get-transac-id-date', component: GetTransacIdDateComponent, canActivate: [AuthGuard] },
  { path: 'get-all-transac', component: GetAllTransacComponent, canActivate: [AuthGuard, RoleGuard] },
  { path: '**', redirectTo: '/login' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
