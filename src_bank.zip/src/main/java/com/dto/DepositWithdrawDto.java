package com.dto;

public class DepositWithdrawDto {
	private double amount;
	private long senderAccNo;
	private long targetAccNo;
	public DepositWithdrawDto() {
		// TODO Auto-generated constructor stub
	}
	public DepositWithdrawDto(double amount) {
		
		this.amount = amount;
	}
	public DepositWithdrawDto(double amount, long senderAccNo, long targetAccNo) {
	
		this.amount = amount;
		this.senderAccNo = senderAccNo;
		this.targetAccNo = targetAccNo;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public long getSenderAccNo() {
		return senderAccNo;
	}

	public void setSenderAccNo(long senderAccNo) {
		this.senderAccNo = senderAccNo;
	}

	public long getTargetAccNo() {
		return targetAccNo;
	}

	public void setTargetAccNo(long targetAccNo) {
		this.targetAccNo = targetAccNo;
	}
	
	
}
