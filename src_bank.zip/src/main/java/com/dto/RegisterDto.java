package com.dto;

import com.entity.Address;
import com.entity.Login;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Size;

public class RegisterDto {
	@Override
	public String toString() {
		return "RegisterDto [fullName=" + fullName + ", contactNo=" + contactNo + ", address=" + address + ", login="
				+ login + "]";
	}
	@Size(min=3, max=20, message="Name must be between 3 to 20 characters")
	private String fullName;
	
	@Size(min=10, max=10, message="Enter a 10 digit contact number")
	private String contactNo;
	
	@Valid
	private Address address;
	@Valid
	private Login login;
	
	
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public String getContactNo() {
		return contactNo;
	}
	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public Login getLogin() {
		return login;
	}
	public void setLogin(Login login) {
		this.login = login;
	}
	
	
}
