package com.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dto.CustDto;
import com.dto.RegRespDto;
import com.dto.RegisterDto;
import com.entity.Address;
import com.entity.Customer;
import com.entity.Login;
import com.exception.CustomerFoundException;
import com.exception.CustomerNotFoundException;
import com.repository.CustomerRepo;
import com.repository.LoginRepo;

import jakarta.transaction.Transactional;

@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	CustomerRepo custRepo;
	@Autowired
	LoginRepo loginRepo;
	
	
	@Override
	public Customer addCustomer(Customer customer) throws CustomerFoundException {
		if(customer.getLogin().getEmail().equals(custRepo.findByEmail(customer.getLogin().getEmail()))) {
			throw new CustomerFoundException("Customer already exists!!!");
		}
		return custRepo.save(customer);	
	}

	@Override
	public List<CustDto> getAllCustomers() {
		List<Customer> clist= custRepo.findAll();
		List<CustDto> custDto=new ArrayList<>();
		for(Customer a:clist) {
			CustDto c=new CustDto();
			c.setName(a.getFullName());
			c.setCustId(a.getCustId());
			c.setContactNo(a.getContactNo());
			c.setRole(a.getLogin().getRole());
			custDto.add(c);
		}
		return custDto;
	}
	
	@Transactional
	@Override
	public Customer findCustomerById(long custId) throws CustomerNotFoundException{
		return custRepo.findById(custId)
		        .orElseThrow(() -> new CustomerNotFoundException("No Customer Exists with the ID " + custId));
	}

	@Transactional
	@Override
	public Customer updateCustomerById(long custId, Customer cust) throws CustomerNotFoundException{
		Customer customer=custRepo.findById(custId).orElseThrow(() -> new CustomerNotFoundException("No Customer Exists with the ID " + custId));
		customer.setContactNo(cust.getContactNo());
		customer.setFullName(cust.getFullName());
		Address addr= cust.getAddr();
		customer.setAddr(addr);
		Login login=cust.getLogin();
		customer.setLogin(login);
		
		return custRepo.save(customer);
	}

	@Transactional
	@Override
	public void deleteCustomer(long custId) throws CustomerNotFoundException{
		Customer customer = custRepo.findById(custId).orElseThrow(() -> new CustomerNotFoundException("No Customer Exists with the ID " + custId));
		custRepo.delete(customer);
	}

	@Transactional
	@Override
	public Customer updateCustomerName(long custId, String name) throws CustomerNotFoundException{
		Customer customer=custRepo.findById(custId).orElseThrow(() -> new CustomerNotFoundException("No Customer Exists with the ID " + custId));
		customer.setFullName(name);
		return custRepo.save(customer);
	}

	@Transactional
	@Override
	public Customer updateCustomerAddr(long custId, Address addr)throws CustomerNotFoundException {
		Customer customer=custRepo.findById(custId).orElseThrow(() -> new CustomerNotFoundException("No Customer Exists with the ID " + custId));
		customer.getAddr().setCity(addr.getCity());
		customer.getAddr().setdNo(addr.getdNo());
		customer.getAddr().setPincode(addr.getPincode());
		customer.getAddr().setState(addr.getState());
		customer.getAddr().setStreetName(addr.getStreetName());
		addr.setCustomer(customer);
		return custRepo.save(customer);
	}

	@Override
	public List<Customer> getCustomerByName(String name) throws CustomerNotFoundException{
		return custRepo.findByfullName(name);
	}

	@Override
	public CustDto getCustDtoById(long custId) throws CustomerNotFoundException{
		Customer customer=custRepo.findById(custId).orElseThrow(() -> new CustomerNotFoundException("No Customer Exists with the ID " + custId));
		CustDto cust=new CustDto();
		cust.setCustId(custId);
		cust.setContactNo(customer.getContactNo());
		cust.setName(customer.getFullName());
		return cust;
	}

	@Transactional
	@Override
	public CustDto updateCustDtoById(long custId, CustDto customer)throws CustomerNotFoundException{
		Customer cust=custRepo.getById(custId);
		cust.setFullName(customer.getName());
		cust.setContactNo(customer.getContactNo());
		cust.setAddr(cust.getAddr());
		cust.setLogin(cust.getLogin());
		custRepo.save(cust);
		CustDto c= new CustDto();
		c.setCustId(cust.getCustId());
		c.setContactNo(customer.getContactNo());
		c.setName(customer.getName());
		return c;
		
		
	}

	@Override
	public Customer findByLogin(Login login){
		Customer cust = custRepo.findByLogin(login);
		return cust;
	}

	@Override
	public Customer findByEmail(String email) {
		return custRepo.findByEmail(email);
	}

}
