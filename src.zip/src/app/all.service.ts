import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { catchError, map, Observable, throwError } from 'rxjs';

export interface Register {
  custId: number;
  email: string;
  message: string;
}

export interface Login {
  [key: string]: string;
}

export interface Account {
  custId: number;
  accType: string;
  balance: number;
  createdAt: Date;
}
export interface Balance {
  amount: number;  
}

export interface JsonResponse {
  message: string;
}

export interface AccountDto {
  accountId: number;
  custId: number;
  accType: string;
  balance: number;
  createdAt: Date;
  freeze: boolean;
}

export interface Customer {
  custId: number;
  fullName: string;
  contactNo: string;
  addrId: number;
  email: string;
}

export interface CustomerDto {
  custId: number;
  name: string;
  contactNo: string;
  role: string;
}

export interface Transaction {
  tranId: number;
  amount: number;
  accountId: number;
  receiverAccNo: number;
  senderAccNo: number;
  status: string;
  timeStamp: string;
  transType: string;
  custId: number;
}

@Injectable({
  providedIn: 'root'
})


export class AuthService {
  private url = 'http://localhost:9095/';
  private isAuthenticated: boolean = false;
  private userRole: string = '';
  private balance: number=0;
  constructor(private http: HttpClient) { }


  // user registration
  register(user: any): Observable<Register> {
    return this.http.post<Register>(this.url + 'auth/register', user);
  }

  // user login
  userLogin(email: string, password: string): Observable<Login> {
    const data = { email, password };

    return this.http.post<Login>(this.url + 'auth/login', data).pipe(
      map(response => {
        if (response) {
          sessionStorage.setItem('isAuthenticated', 'true');
          sessionStorage.setItem('userEmail', email);
          this.getRole(email).subscribe(role => {
            sessionStorage.setItem('userRole', role);
          });

          return response as Login;
        }
        return {} as Login;
      }),
      catchError(this.handleError)
    );
  }

  // handle login error
  private handleError(error: HttpErrorResponse) {
    let errorMessage = 'An unknown error occurred!';
    if (error.error instanceof ErrorEvent) {
      errorMessage = `Error: ${error.error.message}`;

      if (error.status === 401) {
        errorMessage = 'Invalid email or password';
      } else {
        errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
      }
    }
    return throwError(errorMessage);
  }

  //get user role
  getRole(email: string): Observable<string> {
    return this.http.get(`${this.url}auth/role?email=${email}`, { responseType: 'text' });
  }

  // check if user is logged in
  isLoggedIn(): boolean {
    return sessionStorage.getItem('isAuthenticated') === 'true';
  }

  // user logout
  logout() {
    sessionStorage.clear();
  }

  // Account
  //create an account  
  createAccount(accountData: Account): Observable<Account> {
    return this.http.post<Account>(`${this.url}accounts`, accountData);
  }

  // delete account
  deleteAccount(accId: number): Observable<JsonResponse> {
    return this.http.delete<JsonResponse>(`${this.url}accounts/${accId}`);
  }

  // get account details by Account ID
  getAccountById(accId: number): Observable<AccountDto> {
    return this.http.get<AccountDto>(`${this.url}accounts/${accId}`);
  }

  // get account details by Customer ID
  getAccountsByCustomerId(customerId: number): Observable<AccountDto[]> {
    return this.http.get<AccountDto[]>(`${this.url}accounts/customer/${customerId}`,);
  }

  // Get all account details
  getAccounts(): Observable<AccountDto[]> {
    return this.http.get<AccountDto[]>(this.url + 'accounts')
  }

  // Get account Balance
  getAccountBalance(accId: number): Observable<Balance> {
    return this.http.get<Balance>(`${this.url}accounts/${accId}/balance`)
  }
  // Freeze user account
  freezeAccount(accountId: number): Observable<JsonResponse> {
    return this.http.patch<JsonResponse>(`${this.url}accounts/${accountId}/freeze`, {});
  }

  // Unfreeze User account
  unfreezeAccount(accountId: number): Observable<JsonResponse> {
    return this.http.patch<JsonResponse>(`${this.url}accounts/${accountId}/unfreeze`, {});
  }

  // Verify user account exists
  verifyAccountExists(accId: number): Observable<JsonResponse> {
    return this.http.get<JsonResponse>(`${this.url}accounts/exists/${accId}`);
  }

  // Customer
  // get all Customer details
  getAllCustomers(): Observable<CustomerDto[]> {
    return this.http.get<CustomerDto[]>(this.url + 'customers');
  }
  // Get customer details using email
  getCustomerDetails(email: string): Observable<Customer> {
    return this.http.get<Customer>(`${this.url}customers/email?email=${email}`)
  }

  // add a customer
  addCustomer(customer: Customer): Observable<Customer> {
    return this.http.post<Customer>(`${this.url}customers`, customer).pipe(
      catchError(error => {
        return throwError(error.error.message || "An error occurred while adding the customer");
      })
    );
  }

  // Delete a customer
  deleteCustomer(custId: number): Observable<JsonResponse> {
    return this.http.delete<JsonResponse>(`${this.url}customers/${custId}`).pipe(
      catchError(error => {
        return throwError(error.error.message || `Error deleting customer`);
      })
    );
  }

  // Update Customer name
  updateCustomerName(custId: number, name: string): Observable<Customer> {
    return this.http.patch<Customer>(`${this.url}customers/${name}/${custId}`, null).pipe(
      catchError(error => {
        return throwError(error.error.message || `Error updating customer name`);
      })
    );
  }

  // Update customer Address
  updateCustomerAddress(custId: number, address: any): Observable<Customer> {
    return this.http.patch<Customer>(`${this.url}customers/${custId}`, address).pipe(
      catchError(error => {
        return throwError(error.error.message || `Error updating customer address`);
      })
    );
  }

  // get customer details by Customer ID
  getCustomerById(custId: number): Observable<Customer> {
    return this.http.get<Customer>(`${this.url}customers/${custId}`).pipe(
      catchError(error => {
        return throwError(error.error.message || `Error fetching customer details`);
      })
    );
  }

  // update customer details
  updateCustomer(custId: number, customer: Customer): Observable<CustomerDto> {
    return this.http.put<CustomerDto>(`${this.url}customer/${custId}`, customer).pipe(
      catchError(error => {
        return throwError(error.error.message || `Error updating customer`);
      })
    );
  }

  // Transactions
  // Deposit amount into account
  deposit(amount: number, accId: number): Observable<{ status: string, message: string }> {
    const reqBody = { amount }
    return this.http.post<{ status: string, message: string }>(`${this.url}accounts/${accId}/deposit`, reqBody);
  }

  // withdraw amount from account
  withdraw(amount: number, accId: number): Observable<{ status: string, message: string }> {
    const reqBody = { amount }
    return this.http.post<{ status: string, message: string }>(`${this.url}accounts/${accId}/withdraw`, reqBody);
  }

  // Transfer amount from one account to another
  transfer(sourceAccId: number, targetAccId: number, amount: number): Observable<{ status: string, message: string }> {
    const requestBody = { amount };
    return this.http.post<{ status: string, message: string }>(`${this.url}accounts/${sourceAccId}/transfer/${targetAccId}`, requestBody);
  }

  // get transaction details of a particular account
  getTransactionsByAccountId(accId: number): Observable<Transaction[]> {
    return this.http.get<Transaction[]>(`${this.url}accounts/${accId}/transactionsbyId`);
  }

  // get transaction details of a particular account and between dates
  getTransactionsByAccountIdAndDateRange(accId: number, startDate: string, endDate: string): Observable<Transaction[]> {
    return this.http.get<Transaction[]>(`${this.url}accounts/${accId}/transactions?startDate=${startDate}&endDate=${endDate}`);
  }

  // get all transactions
  getAllTransactions(): Observable<Transaction[]> {
    return this.http.get<Transaction[]>(`${this.url}accounts/transactions`);
  }
}
