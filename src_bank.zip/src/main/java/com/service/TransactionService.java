package com.service;
 
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import com.dto.TransactionDto;
import com.entity.Transaction;
 
public interface TransactionService {
	Map<String, String> deposit(double amount,long accId);
	Map<String, String> withdraw(double amount,long accId);
	Map<String, String> transferAmount(long sourceAccId,long targetAccId,double amount);
	List<TransactionDto> getTransactionsByAccountId(Long accId);
	List<TransactionDto> getTransactionsByAccountIdAndDateRange(Long accId, LocalDateTime startDate, LocalDateTime endDate);
	List<TransactionDto> getAllTransaction();
}	