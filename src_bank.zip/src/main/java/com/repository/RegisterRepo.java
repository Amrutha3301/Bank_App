package com.repository;

import com.dto.RegRespDto;
import com.dto.RegisterDto;

public interface RegisterRepo {
	RegRespDto regCustomer(RegisterDto cust);
}
