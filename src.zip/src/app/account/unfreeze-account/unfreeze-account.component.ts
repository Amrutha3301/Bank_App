import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/all.service';

@Component({
  selector: 'app-unfreeze-account',
  templateUrl: './unfreeze-account.component.html',
  styleUrls: ['./unfreeze-account.component.css']
})
export class UnfreezeAccountComponent implements OnInit {
  accounts: any[] = [];
  message: string = '';
  errorMessage: string = '';

  constructor(private accountService: AuthService) { }

  ngOnInit(): void {
    this.getAllAccounts();
  }

  getAllAccounts(): void {
    this.accountService.getAccounts().subscribe({
      next: (data) => this.accounts = data.filter(account => account.freeze === true),
      error: (err) => console.error('Error fetching accounts:', err)
    });
  }

  unfreezeAccount(accountId: number): void {
    this.accountService.unfreezeAccount(accountId).subscribe(
      (response) => {
        this.message = response.message
        this.getAllAccounts();
      },
      (error) => {
        this.errorMessage = 'Error unfreezing account: ' + error.message;
      }
    );
  }

}
