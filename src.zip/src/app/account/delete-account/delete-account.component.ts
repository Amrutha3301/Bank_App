import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from 'src/app/all.service';

@Component({
  selector: 'app-delete-account',
  templateUrl: './delete-account.component.html',
  styleUrls: ['./delete-account.component.css']
})

export class DeleteAccountComponent implements OnInit {
  accounts: any[] = [];
  deleteAccountForm!: FormGroup;

  constructor(private fb: FormBuilder, private accountService: AuthService) { }

  ngOnInit(): void {
    this.loadAccounts();
  }

  loadAccounts(): void {
    const email = sessionStorage.getItem('userEmail');
    if (email) {
      this.accountService.getCustomerDetails(email).subscribe(data => {
        const customerId = Number(data.custId);
        this.accountService.getAccountsByCustomerId(customerId).subscribe(accounts => {
          this.accounts = accounts;
        });
      });
    }
  }

  deleteAccount(accId: number): void {
    this.accountService.deleteAccount(accId).subscribe(() => {
      this.accounts = this.accounts.filter(account => account.accountId !== accId);
    });
  }
}
