import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from 'src/app/all.service';

@Component({
  selector: 'app-add-account',
  templateUrl: './add-account.component.html',
  styleUrls: ['./add-account.component.css']
})
export class AddAccountComponent implements OnInit {
  addAccountForm!: FormGroup;
  successMessage = '';

  constructor(private fb: FormBuilder, private service: AuthService) { }

  ngOnInit() {
    this.addAccountForm = this.fb.group({
      accType: ['', Validators.required],
      customerId: [{ value: '', disabled: true }],
      balance: ['', [Validators.required, Validators.min(500)]],
      createdAt: ['']
    });

    const email = sessionStorage.getItem('userEmail');

    if (email) {
      this.service.getCustomerDetails(email).subscribe(data => {
        const customerId = Number(data.custId);
        this.addAccountForm.patchValue({ customerId: customerId });
      });
    }
  }
  onSubmit() {
    if (this.addAccountForm.valid) {
      const formValues = this.addAccountForm.getRawValue();

      this.service.createAccount(formValues).subscribe(response => {
        console.log('Account Created:', response);
        this.successMessage = 'Account successfully created!';
      });
    }
  }
}
