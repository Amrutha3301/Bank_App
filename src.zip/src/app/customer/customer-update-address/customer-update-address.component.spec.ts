import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerUpdateAddressComponent } from './customer-update-address.component';

describe('CustomerUpdateAddressComponent', () => {
  let component: CustomerUpdateAddressComponent;
  let fixture: ComponentFixture<CustomerUpdateAddressComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomerUpdateAddressComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CustomerUpdateAddressComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
