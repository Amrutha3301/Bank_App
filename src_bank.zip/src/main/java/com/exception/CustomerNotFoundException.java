package com.exception;


public class CustomerNotFoundException extends Exception {
	public CustomerNotFoundException() {
		// TODO Auto-generated constructor stub
	}
	
	public CustomerNotFoundException(String msg) {
		super(msg);
	}
}
