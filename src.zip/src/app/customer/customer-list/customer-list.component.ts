import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/all.service';


@Component({
  selector: 'app-customer-list',
  templateUrl: './customer-list.component.html',
  styleUrls: ['./customer-list.component.css']
})
export class CustomerListComponent implements OnInit {
  customers: any[] = [];

  constructor(private authService: AuthService) { }

  ngOnInit(): void {
    this.getAllCustomers();
  }

  getAllCustomers(): void {
    this.authService.getAllCustomers().subscribe({
      next: (data) => this.customers = data,
      error: (err) => console.error('Error fetching customers:', err)
    });
  }
}
